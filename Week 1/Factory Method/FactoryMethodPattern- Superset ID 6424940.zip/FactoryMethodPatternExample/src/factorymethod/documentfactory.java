package factorymethod;

public abstract class documentfactory {
    public abstract document createdocument();
}