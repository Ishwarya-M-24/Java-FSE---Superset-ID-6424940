package factorymethod;

public interface document {
    void open();
}