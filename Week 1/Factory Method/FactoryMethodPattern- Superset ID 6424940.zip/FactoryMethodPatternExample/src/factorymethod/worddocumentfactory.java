package factorymethod;

public class worddocumentfactory extends documentfactory {
    public document createdocument() {
        return new worddocument();
    }
}