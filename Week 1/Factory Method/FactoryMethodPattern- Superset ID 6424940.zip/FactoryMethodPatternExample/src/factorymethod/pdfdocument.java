package factorymethod;

public class pdfdocument implements document {
    public void open() {
        System.out.println("Opening PDF Document");
    }
}