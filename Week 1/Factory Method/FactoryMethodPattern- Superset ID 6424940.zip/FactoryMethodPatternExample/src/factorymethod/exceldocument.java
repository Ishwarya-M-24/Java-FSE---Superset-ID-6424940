package factorymethod;

public class exceldocument implements document {
    public void open() {
        System.out.println("Opening Excel Document");
    }
}