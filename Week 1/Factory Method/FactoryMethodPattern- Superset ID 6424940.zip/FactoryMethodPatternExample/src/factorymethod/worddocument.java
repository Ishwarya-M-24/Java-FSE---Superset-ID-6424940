package factorymethod;

public class worddocument implements document {
    public void open() {
        System.out.println("Opening Word Document");
    }
}
