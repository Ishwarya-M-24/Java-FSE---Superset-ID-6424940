package factorymethod;

public class pdfdocumentfactory extends documentfactory {
    public document createdocument() {
        return new pdfdocument();
    }
}
