package factorymethod;

public class exceldocumentfactory extends documentfactory {
    public document createdocument() {
        return new exceldocument();
    }
}