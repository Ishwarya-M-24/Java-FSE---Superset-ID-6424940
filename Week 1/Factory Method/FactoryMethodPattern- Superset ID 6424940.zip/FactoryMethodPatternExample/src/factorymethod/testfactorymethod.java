package factorymethod;

public class testfactorymethod {
    public static void main(String[] args) {
        documentfactory wordfactory = new worddocumentfactory();
        document worddoc = wordfactory.createdocument();
        worddoc.open();

        documentfactory pdffactory = new pdfdocumentfactory();
        document pdfdoc = pdffactory.createdocument();
        pdfdoc.open();

        documentfactory excelfactory = new exceldocumentfactory();
        document exceldoc = excelfactory.createdocument();
        exceldoc.open();
    }
}